"use client"
import React from 'react'
import Login from '../../src/components/Login'

export default function LoginPage() {
  return <Login />
}
