# PPS

This project is built using **React + Vite**.

It provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

## Features
- Fast Refresh (HMR)
- ESLint configuration
- Modern React setup with Vite

## Development
To start the project locally:
```bash
npm install
npm run dev