import React from "react";

const Proh = () => {
  return (
    <div className=" bg-gray-100 h-32 flex justify-center">
      <h1 className="font-bold text-3xl md:text-5xl text-center my-10">
        Boost your digital presence with Marketcall
      </h1>
    </div>
  );
};

export default Proh;
