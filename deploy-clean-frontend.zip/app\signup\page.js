"use client"
import React from 'react'
import Signup from '../../src/components/Signup'

export default function SignupPage() {
  return <Signup />
}
